import logo from "./logo.svg";
import "./App.css";
import Forms from "./Components/Forms";

function App() {
  return (
    <div className="App">
      <Forms />
    </div>
  );
}

export default App;
